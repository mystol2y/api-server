const express = require('express');
const router = express.Router();
const mysql = require('mysql');
const util = require('util');
const moment = require('moment');
const md5 = require('md5');
const sha1 = require('sha1');
const { json } = require('body-parser');
const con = mysql.createPool({
    host: '207.148.79.76',
    user: 'huayhubexpress',
    password: 'Oa0c4!g8',
    database: 'huayhubexpress'
});
const query = util.promisify(con.query).bind(con);
let date = new Date();
let formatedate = moment(date).format('Y-MM-DD H:m:ss');
let year = moment(date).format('Y-MM-DD');

con.getConnection((err, connection) => {
    if (err) {
        if (err.code === 'PROTOCOL_CONNECTION_LOST') {
            console.error('Database connection was closed.')
        }
        if (err.code === 'ER_CON_COUNT_ERROR') {
            console.error('Database has too many connections.')
        }
        if (err.code === 'ECONNREFUSED') {
            console.error('Database connection was refused.')
        }
    }

    if (connection) connection.release()

    return
})
router.post('/', async function (req, res) {
    let
        title = req.body.title,
        body = req.body.body,
        author = req.body.author,
        img_name,
        img,
        description = req.body.description;
    let sql = await query("INSERT INTO news (" +
        "title," +
        "body," +
        "author," +
        "publish" +
        ")" +
        "VALUES(" +
        "'" + title + "'," +
        "'" + body + "'," +
        "'" + author + "'," +
        "1" +
        ")"
        // , async (err, result) => {
        // for (const [key, value] of Object.entries(img)) {
        //     await value.mv('./assets/image/media/news-' + key + '-' + formatedate + '.jpg');
        //     image_name[key] = 'news-' + key + '-' + formatedate + '.jpg';
        //     await query("INSERT INTO media (" +
        //         "type," +
        //         "img_name," +
        //         "description," +
        //         "created_date," +
        //         "title," +
        //         "ref_id," +
        //         ")" +
        //         "VALUES(" +
        //         "2," +
        //         "'" + key + "'," +
        //         "'" + image_name[key] + "'," +
        //         "'" + create_date + "'," +
        //         "" +
        //         "'news" + result.insertId + "'" +
        //         ")"
        //     );
        // }
        // });
    );
    res.json(sql);
    if (sql) {
    }
});
router.post('/update', async function (req, res) {
    let id = req.body.id
    title = req.body.title,
        body = req.body.body,
        author = req.body.author,
        publish = req.body.publish
    let sql = await query("UPDATE news SET " +
        "title ='" + title + "'," +
        "body ='" + body + "'," +
        "author ='" + author + "'," +
        "publish =" + publish + "" +
        " WHERE id =" + id + ""
    );
    if (sql)
        res.json(sql)
});
router.post('/delete', async function (req, res) {
let sql = await query("DELETE FROM news WHERE id ="+req.body.id)
    res.json(sql)
});
router.get('/read', async function (req, res) {
    let sql = await query("SELECT * FROM news WHERE publish =1")
    res.json(sql)
});


module.exports = router;